import java.util.*;
public class StackOperations
{
 private int maxSize; 
 private int top; 
 private int[] stackArray; 
 public StackOperations(int size)
 {
 maxSize = size;
 stackArray = new int[maxSize];
 top = -1;  
 }
 
 public void push(int value)
 {
 if (isFull())
 {
 System.out.println("Stack is full. Cannot push " + value);
 }
 else
 {
 top++; 
 stackArray[top] = value; 
 System.out.println("Pushed " + value + " onto the stack.");
 }
 }

 public int pop()
 {
 if (isEmpty())
 {
 System.out.println("Stack is empty. Cannot pop.");
 return -1; 
 }
 else
 {
 int poppedValue = stackArray[top]; 
 top--; 
 System.out.println("Popped " + poppedValue + " from the stack.");
 return poppedValue; 
 }
 }
 
 public boolean isEmpty()
 {
 return top == -1;
 }

 public boolean isFull()
 {
 return top == maxSize - 1;
 }

 public void display()
 {
 if (isEmpty())
 {
 System.out.println("Stack is empty.");
 } else {
 System.out.print("Stack elements: ");
 for (int i = 0; i <= top; i++)
 {
 System.out.print(stackArray[i] + " ");
 }
 System.out.println();
 }
 }
 public static void main(String[] args)
 {
 int stackSize = 5;
 StackOperations stack = new StackOperations(stackSize);
 stack.push(1);
 stack.push(2);
 stack.push(3);
 stack.push(4);
 stack.push(5);
 stack.display();
 int poppedValue = stack.pop();
 System.out.println("Popped value: " + poppedValue);
 stack.display();
 }
}
