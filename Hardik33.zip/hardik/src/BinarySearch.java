public class BinarySearch {
    
    public int search(int[] arr, int key) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == key) {
                return mid;
            }

            if (arr[mid] < key) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; 
    }
    public int search(double[] arr, double key) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == key) {
                return mid;
            }

            if (arr[mid] < key) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; 
    }

    public static void main(String[] args) {
        BinarySearch binarySearch = new BinarySearch();

        int[] intArray = {1, 3, 5, 7, 9, 11, 13};
        double[] doubleArray = {1.1, 3.3, 5.5, 7.7, 9.9, 11.11, 13.13};

        int intKey = 7;
        double doubleKey = 7.7;

        int intResult = binarySearch.search(intArray, intKey);
        int doubleResult = binarySearch.search(doubleArray, doubleKey);

        System.out.println("Integer Key found at index: " + intResult);
        System.out.println("Double Key found at index: " + doubleResult);
    }
}
